package com.example.projetointegrador;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button botaoSortear;
    private EditText textoDigitado;
    private String []equipe1 = {"Sara", "Alicia" "Lara"};
    private String []equipe2 =  {"Alan", "Danylo", "Victor", "Felipe"};
    private String []equipe3 = {"Mateus ", "De Cellis", "Suennaby", "Jorge", "Augusto", "Thiago"};
    private String [] equipe4 = {'Gabriel', "Lucas", "Fabricio", "Bruno", "Eduardo"};
    private String [] equipe5 = {" icaro"," Viniciu","Tayrone","Carlos","Hyago",};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        botaoSortear = findViewById( R. id. bt_sorteio);
        textoDigitado =  findViewById( R. id . tf_numero);

        botaoSortear

        if (!textoDigitado.getText().toString().isEmpty()){
            int numero = Integer.parseInt(textoDigitado.getText().toString());
            String nome="";
            if (numero>= 1 && numero <=5){



                if ( numero==1) {
                    nome == equipe1[new Random().nextInt(equipe1.length)];
                }else  if (numero ==2){
                    nome == equipe2 [new  Random().nextInt(equipe2.length)];
                }else  if (numero ==3){
                    nome == equipe3 [new  Random().nextInt(equipe3.length)];
                }else  if (numero ==4){
                    nome == equipe4 [new  Random().nextInt(equipe4.length)];
                }else  if (numero ==5){
                    nome == equipe5 [new  Random().nextInt(equipe5.length)];
                }
                Toast.makeText(this, nome Toast.LENGTH_LONG).show();
            }
        }































        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
